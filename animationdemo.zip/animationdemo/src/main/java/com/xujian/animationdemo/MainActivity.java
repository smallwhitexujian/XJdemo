package com.xujian.animationdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


/**
 * Created by:      xujian
 * Version          ${version}
 * Date:            16/4/13
 * Description(描述):
 * Modification  History(历史修改):
 * Date              Author          Version
 * ---------------------------------------------------------
 * 16/4/13          xujian         ${version}
 * Why & What is modified(修改原因):
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btn, btn1, btn2;
    private LinearLayout line1;
    private TextView textView;
    private ImageView imageView;
    private Animation translateAnimation_in,translateAnimation_out,translate_in, scaleAnimation;
    private int i = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView) findViewById(R.id.img);
        line1 = (LinearLayout) findViewById(R.id.line1);
        textView = (TextView) findViewById(R.id.numText);
        btn = (Button) findViewById(R.id.btn);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        line1.setVisibility(View.VISIBLE);
        translateAnimation_in = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_in_anim);
        translate_in = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade2_in_anim);

        translateAnimation_out = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_out_anim);
        scaleAnimation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.thepinanim);

        translateAnimation_in.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                textView.setVisibility(View.VISIBLE);
                textView.startAnimation(scaleAnimation);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                line1.startAnimation(translateAnimation_out);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        line1.startAnimation(translateAnimation_in);
        imageView.startAnimation(translate_in);

        btn.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn:
                line1.setVisibility(View.VISIBLE);
                line1.startAnimation(translateAnimation_in);
                imageView.startAnimation(translate_in);
                translateAnimation_in.reset();
                translate_in.reset();
                break;
            case R.id.btn1:
                break;
            case R.id.btn2:
                i++;
                String str = "x"+i;
                translateAnimation_out.start();
                textView.setText(str);
                textView.startAnimation(scaleAnimation);
                break;
        }
    }
}
